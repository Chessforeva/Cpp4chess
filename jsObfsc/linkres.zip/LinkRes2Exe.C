/* *************************************************************
   Created with BCX -- The BASIC To C Translator (ver 5.09.1108)
   BCX (c) 1999 - 2006 by Kevin Diggins
   *************************************************************
     Translated for compiling with a C Compiler
   *************************************************************

   ------------------------------------------------------------------------------
    LinkRes2Exe  (c)2006 by Mike Henning
   ------------------------------------------------------------------------------
    This program is free to use and modify for personal or commercial use as long
    as Link2Res itself is not being redistributed for profit.
    Any use of this program is at the users own risk. The author will not be held
    responsible for any damage that may result directly or indirectly.
   ------------------------------------------------------------------------------
*/

#include <windows.h>    // Win32 Header File 
#include <stdio.h>
#include <stdlib.h>


// *************************************************
// Instruct Linker to Search Object/Import Libraries
// *************************************************
#pragma comment(lib,"kernel32.lib")

// *************************************************
//          User Defined Types And Unions
// *************************************************

typedef struct _ResHeader
{
DWORD  DataSize;
DWORD  HeaderSize;
DWORD  ResType;
DWORD  ResName;
DWORD  DataVersion;
WORD   MemFlags;
WORD   LangId;
DWORD  Version;
DWORD  Charistics;
}ResHeader, *LPRESHEADER;


// *************************************************
//            User Global Variables
// *************************************************

static int    Verbose;
static FILE   *FP1;


// *************************************************
//               Standard Macros
// *************************************************

#define BAND &
#define GET(A,B,C) fread(B,1,C,A)


// *************************************************
//               Standard Prototypes
// *************************************************

int     str_cmp(char*, char*);
char*   BCX_TmpStr(size_t);
char*   string (int,int);
char*   hex (int);
char*   join (int, ... );
DWORD   lof (char*);

// *************************************************
//               User Prototypes
// *************************************************

int     AddRes2File (char *, char *);
LPCSTR  RetResType (int);
LPSTR   RetMemFlags (int);
DWORD   dwAlign (DWORD);

// *************************************************
//                  Main Program
// ************************************************* 

int main(int argc, char *argv[])
{
   
if(argc>3)
  {
    if(str_cmp(argv[3],"-verbose")==0)
      {
        Verbose=TRUE;
      }
  }
if(argc>2)
  {
    AddRes2File(argv[1],argv[2]);
  }
else
  {
    printf("%s\n"," LinkRes2Exe (c)2006 Mike Henning");
    printf("%s\n"," Usage: LinkRes2Exe  file.res  file.exe [-verbose]");
  }
  return 0;   //  End of main program
}




// *************************************************
//                 Runtime Functions
// *************************************************

char *BCX_TmpStr (size_t Bites)
{
  static int   StrCnt;
  static char *StrFunc[2048];
  StrCnt=(StrCnt + 1) & 63;
  if(StrFunc[StrCnt]) free (StrFunc[StrCnt]);
  return StrFunc[StrCnt]=(char*)calloc(Bites+128,sizeof(char));
}


int str_cmp (char *a, char *b)
{
  int counter=0;
  while(1)
   {
    if((a[counter]^b[counter]))
     {
      if((UINT) a[counter]>= (UINT) b[counter])
      return  1;
      return -1;
     }
    if(!a[counter]) return 0;
    counter++;
   }
#if !defined( __cplusplus )
 return 0;
#endif
}


char *hex (int a)
{
  char *strtmp = BCX_TmpStr(16);
  sprintf(strtmp,"%X",a);
  return strtmp;
}


char *string (int count, int a)
{
  char *strtmp = BCX_TmpStr(count);
  return (char*)memset(strtmp,a,count);
}


char * join(int n, ...)
{
  int i = n, tmplen = 0;
  char *s_;
  char *strtmp;
  va_list marker;
  va_start(marker, n); // Initialize variable arguments
  while(i-- > 0)
  {
    s_ = va_arg(marker, char *);
    if(s_) tmplen += strlen(s_);
  }
  strtmp = BCX_TmpStr(tmplen);
  va_end(marker); // Reset variable arguments
  i = n;
  va_start(marker, n); // Initialize variable arguments
  while(i-- > 0)
  {
    s_ = va_arg(marker, char *);
    if(s_) strcat(strtmp, s_);
  }
  va_end(marker); // Reset variable arguments
  return strtmp;
}


DWORD lof (char *FileName)
{
  WIN32_FIND_DATA W32FD;
  HANDLE hFile;
  int FSize;
  if(strlen(FileName)==0) return 0;
  hFile=FindFirstFile(FileName,&W32FD);
  if(hFile!=INVALID_HANDLE_VALUE)
   {
     FSize=W32FD.nFileSizeLow;
     FindClose(hFile);
     return FSize;
   }
  return 0;
}



// ************************************
//       User Subs and Functions
// ************************************


int AddRes2File (char *ResFile, char *TgtFile)
{
  HANDLE  h;
  int FileEnd;
  int position=0;
  ResHeader  rh;
  memset(&rh,0,sizeof(rh));
  char *rdata=NULL;
  
  h=BeginUpdateResource(TgtFile,TRUE);
  if(h==NULL)
    {
      printf("%s\n","BeginUpdateResource failed...");
      if(rdata)free(rdata);
      return FALSE;
    }
  FileEnd=lof(ResFile);
  if((FP1=fopen(ResFile,"rb"))==0)
   {
  fprintf(stderr,"Can't open file %s\n",ResFile);exit(1);
   }
  while(1)
    {
      GET(FP1,&rh,sizeof(rh));
      position+=(sizeof(rh));
      if(Verbose)
        {
          printf("%s% d\n","DataSize    =",(int)rh.DataSize);
          printf("%s% d\n","HeaderSize  =",(int)rh.HeaderSize);
          printf("%s%s\n","ResType     = ",RetResType(rh.ResType));
          printf("%s%s\n","ResName     = ",hex(HIWORD(rh.ResName)));
          printf("%s% d\n","DataVersion =",(int)rh.DataVersion);
          printf("%s%s\n","MemFlags    = ",RetMemFlags(rh.MemFlags));
          printf("%s% d\n","LangId      =",(int)rh.LangId);
          printf("%s% d\n","Version     =",(int)rh.Version);
          printf("%s% d\n","Charistics  =",(int)rh.Charistics);
          printf("%s\n",string(60,45));
        }
      rh.DataSize=dwAlign(rh.DataSize);
      
      rdata=calloc(256+rh.DataSize,1);
      GET(FP1,rdata,rh.DataSize);
      position+=(rh.DataSize);
      if(rh.DataSize)
        {
          rh.ResType=HIWORD(rh.ResType);
          rh.ResName=HIWORD(rh.ResName);
          if(UpdateResource(h,(PCHAR)rh.ResType,(PCHAR)rh.ResName,rh.LangId,rdata,rh.DataSize)==0)
            {
              printf("%s\n","UpdateResource failed...");
              if(rdata)free(rdata);
              return FALSE;
            }
        }
      if(!(position<FileEnd))
        {
          break;
        }
    }
  if(FP1)
   {
     fclose(FP1);
     FP1=NULL;
   }
  if(!EndUpdateResource(h,FALSE))
    {
      printf("%s\n","EndUpdateResource failed...");
      if(rdata)free(rdata);
      return FALSE;
    }
  if(rdata)free(rdata);
  return TRUE;
}


LPCSTR RetResType (int ResId)
{
  while(1)
  {
    if(HIWORD(ResId)==0x0000)
      {
        return "NULL";
      }
    if(HIWORD(ResId)==0x0001)
      {
        return "Cursor";
      }
    if(HIWORD(ResId)==0x0002)
      {
        return "Bitmap";
      }
    if(HIWORD(ResId)==0x0003)
      {
        return "Icon";
      }
    if(HIWORD(ResId)==0x0004)
      {
        return "Menu";
      }
    if(HIWORD(ResId)==0x0005)
      {
        return "Dialog";
      }
    if(HIWORD(ResId)==0x0006)
      {
        return "String Table";
      }
    if(HIWORD(ResId)==0x0007)
      {
        return "Font Directory";
      }
    if(HIWORD(ResId)==0x0008)
      {
        return "Font";
      }
    if(HIWORD(ResId)==0x0009)
      {
        return "Accelerators Table";
      }
    if(HIWORD(ResId)==0x000A)
      {
        return "RC Data (custom binary data)";
      }
    if(HIWORD(ResId)==0x000B)
      {
        return "Message table";
      }
    if(HIWORD(ResId)==0x000C)
      {
        return "Group Cursor";
      }
    if(HIWORD(ResId)==0x000E)
      {
        return "Group Icon";
      }
    if(HIWORD(ResId)==0x0010)
      {
        return "Version Information";
      }
    if(HIWORD(ResId)==0x0011)
      {
        return "Dialog Include";
      }
    if(HIWORD(ResId)==0x0013)
      {
        return "Plug'n'Play";
      }
    if(HIWORD(ResId)==0x0014)
      {
        return "VXD";
      }
    if(HIWORD(ResId)==0x0015)
      {
        return "Animated Cursor";
      }
    if(HIWORD(ResId)==0x2002)
      {
        return "Bitmap (new version)";
      }
    if(HIWORD(ResId)==0x2004)
      {
        return "Menu (new version)";
      }
    if(HIWORD(ResId)==0x2005)
      {
        return "Dialog (new version)";
      }
    break;
  }
  return "Unknown";
}


LPSTR RetMemFlags (int flags)
{
  static char MemFlags[2048];
  *MemFlags=0;
  while(1)
  {
    if(0x0010 BAND flags)
      {
        strcpy(MemFlags,"MOVEABLE");
      }
    if(0x0020 BAND flags)
      {
        strcat(MemFlags," PURE");
      }
    if(0x0040 BAND flags)
      {
        strcat(MemFlags," PRELOAD");
      }
    if(0x1000 BAND flags)
      {
        strcat(MemFlags," DISCARDABLE");
      }
    break;
  }
  if(flags==0)
    {
      strcpy(MemFlags,"None");
    }
  return MemFlags;
}


DWORD dwAlign (DWORD ul)
{
  ul+=3;
  ul>>=2;
  ul<<=2;
  return ul;
}
