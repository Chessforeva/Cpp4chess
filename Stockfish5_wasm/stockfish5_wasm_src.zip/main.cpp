/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2008 Tord Romstad (Glaurung author)
  Copyright (C) 2008-2014 Marco Costalba, Joona Kiiski, Tord Romstad

  Stockfish is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Stockfish is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// [Emscript]
#include "my_emscript.h"

// [Emscript]

int main(int argc, char* argv[]) {

  std::string args;
  
	  std::cout << engine_info() << std::endl;

	  UCI::init(Options);
	  Bitboards::init();
	  Position::init();
	  Bitbases::init_kpk();
	  Search::init();
	  Pawns::init();
	  Eval::init();
	  Threads.init();
	  TT.resize(Options["Hash"]);

	  UCI::commandInit();
	  
	  _cout((char *)"Stockfish5\n");		// Hello there
	  
}


extern "C" void uci_command(const char* cmd) {
	UCI::command(cmd);
}

// [Emscript]
// not used, can be added, but why...
extern "C" void set_book(unsigned char* pBookData, unsigned int size) {
	PolyglotBook::setBookData(pBookData, size);
	UCI::command("setoption name OwnBook value true");
}

