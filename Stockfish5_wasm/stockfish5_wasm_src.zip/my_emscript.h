//
// Look for tag [Emscript]
// where my code for Emscripten
// wraparounds, helpers and hacks
//


#include <emscripten.h>

char stdin_data[10000];
char stdout_data[100000];

// To return string from data to Javascript
// (loop till 0)
extern "C" int EMSCRIPTEN_KEEPALIVE _get( int i ) {
  return (int)stdout_data[i];
}

extern "C" int EMSCRIPTEN_KEEPALIVE _clear() {
  return stdout_data[0] = 0;
}

// To set data values from javascript (end with 0)
extern "C" int EMSCRIPTEN_KEEPALIVE _set( int i, int value ) {
  return stdin_data[i]=value;
}

extern "C" void _cout( char* s ) {
	char *r=s, *w=stdout_data;
	while(*w) w++;	// skip to the end
	while(*r) {
		*(w++)=*(r++);
	}
	*(w)=0;
}


// include all

#include "bitboard.h"
#include "bitcount.h"
#include "book.h"
#include "endgame.h"
#include "evaluate.h"
#include "material.h"
#include "misc.h"
#include "movegen.h"
#include "movepick.h"
#include "notation.h"
#include "pawns.h"
#include "platform.h"
#include "position.h"
#include "psqtab.h"
#include "rkiss.h"
#include "search.h"
#include "thread.h"
#include "timeman.h"
#include "tt.h"
#include "types.h"
#include "ucioption.h"



#include "benchmark.cpp"
#include "bitbase.cpp"
#include "bitboard.cpp"
#include "book.cpp"
#include "endgame.cpp"
#include "evaluate.cpp"

#include "material.cpp"
#include "misc.cpp"
#include "movegen.cpp"
#include "movepick.cpp"
#include "notation.cpp"
#include "pawns.cpp"
#include "position.cpp"
#include "search.cpp"
#include "thread.cpp"
#include "timeman.cpp"
#include "tt.cpp"
#include "uci.cpp"
#include "ucioption.cpp"



// perform uci command from stdin_data
extern "C" void EMSCRIPTEN_KEEPALIVE _uci() {
  UCI::command(stdin_data);
}