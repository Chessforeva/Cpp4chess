
  CM version for TinyC, 2021.
  Not a faster one, just other.
  It can find M3 checkmates, but too slow for M4.
    

-----------------------------

  A simple chess checkmate position generator.

 The config file will be created after first time running.
 Adjust search depth there.
 Simple, no need to describe much.
 Try on a new PC...


  Blog: http://chessforeva.blogspot.com/2016/01/gen-mates.html
